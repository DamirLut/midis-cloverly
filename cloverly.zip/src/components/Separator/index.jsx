import style from './style.module.scss';
export default function Separator() {
  return <hr className={style.separator} />;
}
